﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Welcome to Guess the Number!");
        Console.WriteLine("I'm thinking of a number between 1 and 100. Can you guess it?");

        Random random = new Random();
        int randomNumber = random.Next(1, 101);
        int attempts = 0;

        while (true)
        {
            Console.Write("Enter your guess (or 'q' to quit): ");
            string input = Console.ReadLine();

            if (input.ToLower() == "q")
            {
                Console.WriteLine("Quitting game...");
                break;
            }

            if (!int.TryParse(input, out int guess) || guess < 1 || guess > 100)
            {
                Console.WriteLine("Invalid input. Please enter a number between 1 and 100.");
                continue;
            }

            attempts++;

            if (guess < randomNumber)
            {
                Console.WriteLine("Too low! Try again.");
            }
            else if (guess > randomNumber)
            {
                Console.WriteLine("Too high! Try again.");
            }
            else
            {
                Console.WriteLine($"Congratulations! You guessed the number in {attempts} attempts.");
                break;
            }
        }

        Console.WriteLine($"The number was: {randomNumber}");
        Console.WriteLine("Thanks for playing!");
    }
}
